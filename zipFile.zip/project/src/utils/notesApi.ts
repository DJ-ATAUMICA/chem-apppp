import {
  collection,
  addDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  type Unsubscribe,
} from 'firebase/firestore';
import { db } from '@/firebase';
import type { UserNote } from '@/types';

function notesCol(uid: string) {
  if (!db) throw new Error('Firestore is not configured.');
  return collection(db, 'userNotes', uid, 'notes');
}
function sketchesCol(uid: string) {
  if (!db) throw new Error('Firestore is not configured.');
  return collection(db, 'userNotes', uid, 'sketches');
}

export function subscribeNotes(uid: string, cb: (notes: UserNote[]) => void): Unsubscribe {
  const q = query(notesCol(uid), orderBy('updatedAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const notes: UserNote[] = snap.docs.map((d) => {
        const data = d.data();
        return {
          id: d.id,
          title: (data.title as string) ?? '',
          textContent: (data.textContent as string) ?? '',
          updatedAt: (data.updatedAt as { toMillis?: () => number })?.toMillis?.() ?? Date.now(),
        };
      });
      cb(notes);
    },
    (err) => {
      console.error('Failed to load notes:', err);
      cb([]);
    }
  );
}

export async function addNote(
  uid: string,
  title: string,
  textContent: string
): Promise<void> {
  await addDoc(notesCol(uid), {
    title,
    textContent,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteNote(uid: string, noteId: string): Promise<void> {
  if (!db) throw new Error('Firestore is not configured.');
  await deleteDoc(doc(db, 'userNotes', uid, 'notes', noteId));
}

export interface SavedSketch {
  id: string;
  imageDataUrl: string;
  updatedAt: number;
}

export function subscribeSketches(
  uid: string,
  cb: (sketches: SavedSketch[]) => void
): Unsubscribe {
  const q = query(sketchesCol(uid), orderBy('updatedAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => {
      const sketches: SavedSketch[] = snap.docs.map((d) => {
        const data = d.data();
        return {
          id: d.id,
          imageDataUrl: (data.imageDataUrl as string) ?? '',
          updatedAt: (data.updatedAt as { toMillis?: () => number })?.toMillis?.() ?? Date.now(),
        };
      });
      cb(sketches);
    },
    (err) => {
      console.error('Failed to load sketches:', err);
      cb([]);
    }
  );
}

export async function saveSketch(uid: string, imageDataUrl: string): Promise<void> {
  await addDoc(sketchesCol(uid), {
    imageDataUrl,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteSketch(uid: string, sketchId: string): Promise<void> {
  if (!db) throw new Error('Firestore is not configured.');
  await deleteDoc(doc(db, 'userNotes', uid, 'sketches', sketchId));
}
