import type { QuizQuestion, Topic } from '@/types';

const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY as string | undefined;
const GEMINI_MODEL = 'gemini-2.5-flash';
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;

export const isGeminiConfigured = Boolean(GEMINI_API_KEY);

/**
 * System prompt: the quiz generator is deliberately grounded ONLY in the
 * notes text we pass it. This keeps questions accurate to what the student
 * actually studied, rather than the model drawing on general chemistry
 * knowledge that might not match the syllabus phrasing or scope.
 */
function buildPrompt(topic: Topic): string {
  const notesContent = topic.subtopics
    .map((sub) => `### ${sub.title}\n${sub.bodyText}\nKey definitions: ${sub.keyDefinitions.join('; ')}`)
    .join('\n\n');

  return `You are an A-level Chemistry quiz generator for a student revision app called ChemMate.

Using ONLY the notes content provided below, generate exactly 5 multiple-choice questions covering the topic "${topic.title}". Do not introduce facts, numbers, or examples that are not present in the notes provided.

Rules:
- Each question must have exactly 4 answer options.
- Exactly one option is correct.
- Include a short (1-2 sentence) explanation for why the correct answer is correct.
- Vary question difficulty and cover different subtopics from the notes.
- Questions should test understanding, not just word-matching.

Notes content:
${notesContent}

Respond with ONLY valid JSON, no markdown code fences, no commentary, in exactly this shape:
[
  {
    "question": "string",
    "options": ["string", "string", "string", "string"],
    "correctIndex": 0,
    "explanation": "string"
  }
]`;
}

export async function generateQuiz(topic: Topic): Promise<QuizQuestion[]> {
  if (!GEMINI_API_KEY) {
    throw new Error('Gemini API key is not configured. Add VITE_GEMINI_API_KEY to your .env file.');
  }

  const response = await fetch(GEMINI_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: buildPrompt(topic) }] }],
      generationConfig: {
        temperature: 0.6,
        responseMimeType: 'application/json',
      },
    }),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    throw new Error(`Gemini request failed (${response.status}): ${errText || 'Unknown error'}`);
  }

  const data = await response.json();
  const rawText: string | undefined = data?.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!rawText) {
    throw new Error('Gemini returned an empty response.');
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    throw new Error('Could not parse the quiz response. Please try generating again.');
  }

  if (!Array.isArray(parsed) || parsed.length === 0) {
    throw new Error('Quiz response was not in the expected format.');
  }

  return parsed as QuizQuestion[];
}
