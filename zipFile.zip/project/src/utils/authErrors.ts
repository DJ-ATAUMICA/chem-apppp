import type { FirebaseError } from 'firebase/app';

const AUTH_MESSAGES: Record<string, string> = {
  'auth/invalid-email': 'That email address looks malformed.',
  'auth/user-disabled': 'This account has been disabled.',
  'auth/user-not-found': 'No account found with that email.',
  'auth/wrong-password': 'Incorrect email or password.',
  'auth/invalid-credential': 'Incorrect email or password.',
  'auth/email-already-in-use': 'An account already exists with that email.',
  'auth/weak-password': 'Password should be at least 6 characters.',
  'auth/too-many-requests': 'Too many attempts. Please try again shortly.',
  'auth/network-request-failed': 'Network error — check your connection and try again.',
  'auth/operation-not-allowed': 'Email/password sign-in is not enabled for this project.',
};

export function friendlyAuthError(err: unknown): string {
  const code = (err as FirebaseError)?.code ?? '';
  if (code && AUTH_MESSAGES[code]) return AUTH_MESSAGES[code];
  if (err instanceof Error && err.message) return err.message;
  return 'Something went wrong. Please try again.';
}
