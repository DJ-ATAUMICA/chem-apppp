import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

export type ScreenName =
  | 'home'
  | 'as-notes'
  | 'a2-topics'
  | 'quiz-picker'
  | 'my-notes';

interface NavigationContextValue {
  current: ScreenName;
  canGoBack: boolean;
  navigate: (screen: ScreenName) => void;
  goBack: () => void;
  goHome: () => void;
}

const NavigationContext = createContext<NavigationContextValue | undefined>(undefined);

export function NavigationProvider({ children }: { children: ReactNode }) {
  const [stack, setStack] = useState<ScreenName[]>(['home']);

  const navigate = useCallback((screen: ScreenName) => {
    setStack((prev) => [...prev, screen]);
  }, []);

  const goBack = useCallback(() => {
    setStack((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
  }, []);

  const goHome = useCallback(() => {
    setStack(['home']);
  }, []);

  const value = useMemo<NavigationContextValue>(
    () => ({
      current: stack[stack.length - 1],
      canGoBack: stack.length > 1,
      navigate,
      goBack,
      goHome,
    }),
    [stack, navigate, goBack, goHome]
  );

  return <NavigationContext.Provider value={value}>{children}</NavigationContext.Provider>;
}

export function useNavigation(): NavigationContextValue {
  const ctx = useContext(NavigationContext);
  if (!ctx) throw new Error('useNavigation must be used within NavigationProvider');
  return ctx;
}
