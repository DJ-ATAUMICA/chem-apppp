import type { Topic } from '@/types';
import polyestersImg from '@/assets/diagrams/polyester_formation.svg';
import polyamidesImg from '@/assets/diagrams/polyamide_formation.svg';
import polarityImg from '@/assets/diagrams/kevlar_hydrogen_bonding.svg';

export const A2_TOPICS: Topic[] = [
  {
    id: 'polymerisation',
    title: 'Polymerisation',
    subtopics: [
      {
        id: 'types-of-polymerisation',
        title: 'Types of Polymerisation',
        bodyText:
          'Polymers form in two fundamentally different ways. Addition polymerisation joins alkene monomers by opening their C=C double bond — no atoms are lost, and only one type of monomer is needed. Condensation polymerisation joins monomers that each carry two functional groups; when they react, a small molecule (almost always water) is eliminated as a link forms between them. This distinction — whether anything is lost in the reaction — is the fastest way to tell the two mechanisms apart in an exam.',
        keyDefinitions: [
          'Addition polymerisation — monomers with a C=C bond join with no by-product formed',
          'Condensation polymerisation — monomers with two functional groups join, releasing a small molecule (usually water) at each link',
        ],
        diagramImageUrls: [],
      },
      {
        id: 'polyesters',
        title: 'Polyesters',
        bodyText:
          "Polyesters form when a diol reacts with a dicarboxylic acid. Each –OH group on the diol reacts with a –COOH group on the acid, forming an ester link (–COO–) and releasing water. Repeating this along a chain builds the polymer. Terylene (PET) is the most common example, made from benzene-1,4-dicarboxylic acid and ethane-1,2-diol — it's used in drinks bottles, sheeting, and clothing fibres.",
        keyDefinitions: [
          'Ester link — the –C(=O)–O– bond formed between a carboxylic acid and an alcohol group, with water eliminated',
          'Diol — a molecule with two –OH groups, one at each end',
        ],
        diagramImageUrls: [polyestersImg],
      },
      {
        id: 'polyamides',
        title: 'Polyamides',
        bodyText:
          'Polyamides form when a diamine reacts with a dicarboxylic acid, forming an amide link (–CONH–) and releasing water — the same principle as polyesters, but using amine groups (–NH₂) instead of –OH groups. Nylon 6,6 is made from hexanedioic acid and 1,6-diaminohexane. Kevlar uses aromatic monomers instead — benzene-1,4-dicarboxylic acid and 1,4-diaminobenzene — which gives it exceptional rigidity. Some polyamides, like Nylon 6, form from a single monomer that has both an amine and a carboxylic acid group on the same molecule, so it can react with itself. Naming follows a pattern: two different monomers give "Nylon-x,y" (x = carbons in the diamine, y = carbons in the diacid); a single monomer gives "Nylon-x."',
        keyDefinitions: [
          'Amide link — the –C(=O)–NH– bond formed between a carboxylic acid and an amine group, with water eliminated',
          'Diamine — a molecule with two –NH₂ groups',
        ],
        diagramImageUrls: [polyamidesImg],
      },
      {
        id: 'hydrolysis',
        title: 'Hydrolysis of Condensation Polymers',
        bodyText:
          'Condensation polymers can be broken back down into their original monomers by hydrolysis — literally the reverse reaction, with water added back across each link. To find the monomers, break the bond in the middle of the ester or amide link in the repeat unit, then add an –OH to one side and an –H to the other. Ester links hydrolyse fairly readily; amide links are far more resistant and typically need strong acid, high temperature, and prolonged reflux to break — this difference matters for how these plastics behave in the environment.',
        keyDefinitions: [
          'Hydrolysis — breaking a bond using water, the reverse of condensation polymerisation',
        ],
        diagramImageUrls: [],
      },
      {
        id: 'polarity-and-forces',
        title: 'Polarity and Intermolecular Forces in Condensation Polymers',
        bodyText:
          'The C–O and C–N bonds in ester and amide links are polar, giving condensation polymer chains permanent dipoles. This allows hydrogen bonding to form between neighbouring chains — on top of the dipole-dipole and van der Waals forces already present — making condensation polymers generally stronger and more rigid than addition polymers. Kevlar is the standout example: its regular, uniform chain structure lets adjacent chains pack tightly, and extensive hydrogen bonding along the entire length of each chain — reinforced by interactions between its benzene rings — gives it the strength used in bulletproof vests and reinforced tyres.',
        keyDefinitions: [
          'Permanent dipole-dipole force — attraction between polar regions of neighbouring molecules',
          'Hydrogen bond — a strong dipole-dipole attraction between an electronegative atom (like O or N) and a hydrogen attached to another electronegative atom',
        ],
        diagramImageUrls: [polarityImg],
      },
      {
        id: 'addition-polymers-structure',
        title: 'Addition Polymers — Structure and Properties',
        bodyText:
          'Most polyalkene chains (like poly(ethene)) are non-polar, so they rely only on van der Waals forces between chains — weaker than the forces in condensation polymers. Chain structure changes the strength: long, unbranched chains pack closely together, increasing van der Waals forces and making the polymer more rigid and crystalline (high-density polyethene). Short, heavily branched chains can\'t pack as closely, giving a more flexible, weaker material (low-density polyethene). Introducing a halogen changes things further — PVC (polyvinyl chloride) contains C–Cl bonds, which are polar, so PVC chains experience permanent dipole-dipole forces in addition to van der Waals forces, giving it different properties from unhalogenated polyalkenes.',
        keyDefinitions: [
          'Van der Waals forces — weak, temporary attractions between non-polar molecules, strengthened by longer chains and closer packing',
        ],
        diagramImageUrls: [],
      },
      {
        id: 'ptfe-teflon',
        title: 'PTFE (Teflon)',
        bodyText:
          "Teflon (PTFE) is structurally a polyalkene, but every hydrogen is replaced with fluorine. Fluorine's three lone pairs restrict rotation around the C–C bonds, making the chain more rigid and increasing crystallinity. The C–F bond is extremely strong and fluorine's high electronegativity pulls electron density tightly to itself, making PTFE chemically unreactive and giving it its non-stick surface — few substances can bond to it.",
        keyDefinitions: [
          'Electronegativity — the ability of an atom to attract the electron pair in a covalent bond toward itself',
        ],
        diagramImageUrls: [],
      },
      {
        id: 'proteins',
        title: 'Proteins as Condensation Polymers',
        bodyText:
          'Proteins are condensation polymers built from amino acid monomers. When two amino acids react, the –COOH of one and the –NH₂ of the other combine, releasing water and forming a peptide link (the same bond type as an amide link) — this two-amino-acid unit is called a dipeptide. Because each amino acid still has a free –COOH and –NH₂ at its opposite ends, the chain can keep extending. Hydrolysing a protein back into its individual amino acids requires much harsher conditions than a simple ester — typically concentrated hydrochloric acid (around 6 mol/dm³), reflux at 110°C, for as long as 24 hours.',
        keyDefinitions: [
          'Peptide link — the amide bond (–CONH–) joining two amino acids',
          'Dipeptide — two amino acids joined by one peptide link',
        ],
        diagramImageUrls: [],
      },
    ],
  },
];
