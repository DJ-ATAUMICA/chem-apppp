import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { Eraser } from 'lucide-react';

export interface DrawingCanvasHandle {
  getDataUrl: () => string | null;
  clear: () => void;
  isEmpty: () => boolean;
}

interface Point {
  x: number;
  y: number;
}

const STROKE_COLOR = '#0d9488';
const STROKE_WIDTH = 3;
const CANVAS_HEIGHT = 320;

export const DrawingCanvas = forwardRef<DrawingCanvasHandle, { disabled?: boolean }>(
  function DrawingCanvas({ disabled }, ref) {
    const wrapRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const drawing = useRef(false);
    const hasStrokes = useRef(false);
    const lastPoint = useRef<Point | null>(null);
    const [size, setSize] = useState({ w: 320, h: CANVAS_HEIGHT });
    const [hasInk, setHasInk] = useState(false);

    function ctx(): CanvasRenderingContext2D | null {
      return canvasRef.current?.getContext('2d') ?? null;
    }

    function fillBackground() {
      const c = ctx();
      if (!c) return;
      c.fillStyle = '#ffffff';
      c.fillRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
    }

    function doClear() {
      const c = ctx();
      if (!c || !canvasRef.current) return;
      c.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      fillBackground();
      hasStrokes.current = false;
      setHasInk(false);
    }

    useEffect(() => {
      const wrap = wrapRef.current;
      const canvas = canvasRef.current;
      if (!wrap || !canvas) return;

      const resize = () => {
        const rect = wrap.getBoundingClientRect();
        const w = Math.max(200, Math.floor(rect.width));
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        canvas.width = w * dpr;
        canvas.height = CANVAS_HEIGHT * dpr;
        canvas.style.width = `${w}px`;
        canvas.style.height = `${CANVAS_HEIGHT}px`;
        const c = ctx();
        if (c) {
          c.scale(dpr, dpr);
          c.lineCap = 'round';
          c.lineJoin = 'round';
          c.strokeStyle = STROKE_COLOR;
          c.lineWidth = STROKE_WIDTH;
          fillBackground();
        }
        setSize({ w, h: CANVAS_HEIGHT });
        hasStrokes.current = false;
        setHasInk(false);
      };

      resize();
      const ro = new ResizeObserver(resize);
      ro.observe(wrap);
      return () => ro.disconnect();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function pointFromEvent(e: React.PointerEvent): Point {
      const canvas = canvasRef.current!;
      const rect = canvas.getBoundingClientRect();
      return { x: e.clientX - rect.left, y: e.clientY - rect.top };
    }

    function startDraw(e: React.PointerEvent) {
      if (disabled) return;
      e.preventDefault();
      canvasRef.current?.setPointerCapture(e.pointerId);
      drawing.current = true;
      lastPoint.current = pointFromEvent(e);
    }

    function moveDraw(e: React.PointerEvent) {
      if (!drawing.current || disabled) return;
      e.preventDefault();
      const c = ctx();
      const prev = lastPoint.current;
      if (!c || !prev) return;
      const next = pointFromEvent(e);
      c.beginPath();
      c.moveTo(prev.x, prev.y);
      c.lineTo(next.x, next.y);
      c.stroke();
      lastPoint.current = next;
      hasStrokes.current = true;
      setHasInk(true);
    }

    function endDraw(e: React.PointerEvent) {
      if (!drawing.current) return;
      e.preventDefault();
      drawing.current = false;
      lastPoint.current = null;
      try {
        canvasRef.current?.releasePointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
    }

    useImperativeHandle(ref, () => ({
      getDataUrl() {
        const canvas = canvasRef.current;
        if (!canvas || !hasStrokes.current) return null;
        return canvas.toDataURL('image/png');
      },
      clear: doClear,
      isEmpty() {
        return !hasStrokes.current;
      },
    }));

    return (
      <div className="space-y-3">
        <div
          ref={wrapRef}
          className="overflow-hidden rounded-2xl border border-slate-200 bg-white"
        >
          <canvas
            ref={canvasRef}
            onPointerDown={startDraw}
            onPointerMove={moveDraw}
            onPointerUp={endDraw}
            onPointerLeave={endDraw}
            onPointerCancel={endDraw}
            className="block touch-none"
            style={{ width: size.w, height: size.h }}
            aria-label="Drawing canvas"
          />
        </div>
        <button
          type="button"
          onClick={doClear}
          disabled={disabled || !hasInk}
          className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-50"
        >
          <Eraser className="h-4 w-4" />
          Clear canvas
        </button>
      </div>
    );
  }
);
