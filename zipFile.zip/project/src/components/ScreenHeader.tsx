import { ArrowLeft, Home, FlaskConical } from 'lucide-react';
import { useNavigation } from '@/context/NavigationContext';

interface ScreenHeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
}

export function ScreenHeader({ title, subtitle, showBack = true }: ScreenHeaderProps) {
  const { canGoBack, goBack, goHome } = useNavigation();

  return (
    <header className="sticky top-0 z-10 border-b border-slate-100 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-xl items-center gap-3 px-5 py-4">
        {showBack && canGoBack ? (
          <button
            type="button"
            onClick={goBack}
            aria-label="Go back"
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 transition-colors hover:bg-slate-100 active:scale-95"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
        ) : (
          <div className="flex h-10 w-10 items-center justify-center text-teal-600">
            <FlaskConical className="h-6 w-6" />
          </div>
        )}
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-semibold text-slate-900">{title}</h1>
          {subtitle && <p className="truncate text-sm text-slate-500">{subtitle}</p>}
        </div>
        {canGoBack && (
          <button
            type="button"
            onClick={goHome}
            aria-label="Go to home"
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 transition-colors hover:bg-slate-100 active:scale-95"
          >
            <Home className="h-5 w-5" />
          </button>
        )}
      </div>
    </header>
  );
}
