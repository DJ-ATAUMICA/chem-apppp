import { ScreenHeader } from '@/components/ScreenHeader';

export function AsNotesScreen() {
  return (
    <div className="min-h-screen">
      <ScreenHeader title="AS Chem Notes" subtitle="First-year chemistry" />
      <main className="mx-auto max-w-xl px-5 py-10">
        <div className="card-surface flex flex-col items-center p-10 text-center">
          <span className="mb-4 rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-amber-700">
            Coming Soon
          </span>
          <h2 className="text-xl font-bold text-slate-900">This section is launching soon!</h2>
          <p className="mt-2 max-w-xs text-sm text-slate-500">
            We&apos;re still preparing your AS Chemistry notes. Tap a card on the dashboard to
            explore other sections in the meantime.
          </p>
        </div>
      </main>
    </div>
  );
}
