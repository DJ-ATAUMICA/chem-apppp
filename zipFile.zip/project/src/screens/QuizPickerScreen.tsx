import { useState } from 'react';
import {
  BrainCircuit,
  ChevronRight,
  Loader2,
  AlertCircle,
  CheckCircle2,
  XCircle,
  RotateCcw,
  ArrowLeft,
  Trophy,
} from 'lucide-react';
import { ScreenHeader } from '@/components/ScreenHeader';
import { A2_TOPICS } from '@/data/a2Topics';
import { generateQuiz, isGeminiConfigured } from '@/utils/geminiQuiz';
import type { Topic, QuizQuestion } from '@/types';

type Stage = 'picker' | 'loading' | 'error' | 'active' | 'results';

export function QuizPickerScreen() {
  const [stage, setStage] = useState<Stage>('picker');
  const [topic, setTopic] = useState<Topic | null>(null);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [errorMessage, setErrorMessage] = useState('');

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  async function startQuiz(chosenTopic: Topic) {
    setTopic(chosenTopic);
    setStage('loading');
    try {
      const generated = await generateQuiz(chosenTopic);
      setQuestions(generated);
      setCurrentIndex(0);
      setSelected(null);
      setScore(0);
      setStage('active');
    } catch (err) {
      setErrorMessage(err instanceof Error ? err.message : 'Something went wrong.');
      setStage('error');
    }
  }

  function selectOption(index: number) {
    if (selected !== null) return;
    setSelected(index);
    if (index === questions[currentIndex].correctIndex) {
      setScore((s) => s + 1);
    }
  }

  function nextQuestion() {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((i) => i + 1);
      setSelected(null);
    } else {
      setStage('results');
    }
  }

  function resetToPicker() {
    setStage('picker');
    setTopic(null);
    setQuestions([]);
  }

  if (stage === 'picker') {
    return (
      <div className="min-h-screen">
        <ScreenHeader title="Custom AI Quiz" subtitle="Choose a topic to quiz on" />
        <main className="mx-auto max-w-xl px-5 py-8">
          {!isGeminiConfigured && (
            <div className="mb-6 flex items-start gap-2 rounded-2xl bg-amber-50 px-4 py-3 text-sm text-amber-700">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                Gemini API key not detected. Add <code>VITE_GEMINI_API_KEY</code> to your .env
                file to enable quiz generation.
              </span>
            </div>
          )}
          <div className="grid gap-4">
            {A2_TOPICS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => startQuiz(t)}
                disabled={!isGeminiConfigured}
                className="card-surface group flex items-center gap-4 p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:shadow-cardHover focus:outline-none focus:ring-4 focus:ring-indigo-300/30 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-50"
              >
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-indigo-500 text-white shadow-sm transition-transform group-hover:scale-105">
                  <BrainCircuit className="h-7 w-7" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="text-base font-semibold text-slate-900">{t.title}</span>
                  <span className="mt-0.5 block text-sm text-slate-500">
                    Generate 5 AI questions from your notes
                  </span>
                </span>
                <ChevronRight className="h-5 w-5 shrink-0 text-slate-400 transition-transform group-hover:translate-x-0.5" />
              </button>
            ))}
          </div>
        </main>
      </div>
    );
  }

  if (stage === 'loading') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <Loader2 className="h-9 w-9 animate-spin text-indigo-500" />
        <p className="mt-4 text-sm font-medium text-slate-600">
          Generating your quiz on {topic?.title}…
        </p>
        <p className="mt-1 text-xs text-slate-400">Reading your notes and writing questions</p>
      </div>
    );
  }

  if (stage === 'error') {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <AlertCircle className="h-9 w-9 text-red-500" />
        <p className="mt-4 max-w-xs text-sm text-slate-600">{errorMessage}</p>
        <div className="mt-6 flex gap-3">
          <button
            type="button"
            onClick={resetToPicker}
            className="rounded-full border border-slate-200 px-5 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
          >
            Back
          </button>
          {topic && (
            <button
              type="button"
              onClick={() => startQuiz(topic)}
              className="rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-medium text-white hover:bg-indigo-700"
            >
              Try again
            </button>
          )}
        </div>
      </div>
    );
  }

  if (stage === 'results') {
    const pct = Math.round((score / questions.length) * 100);
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-indigo-500 text-white shadow-sm">
          <Trophy className="h-8 w-8" />
        </span>
        <h2 className="mt-5 text-2xl font-bold text-slate-900">
          {score} / {questions.length}
        </h2>
        <p className="mt-1 text-sm text-slate-500">{pct}% on {topic?.title}</p>
        <div className="mt-8 flex gap-3">
          <button
            type="button"
            onClick={resetToPicker}
            className="rounded-full border border-slate-200 px-5 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
          >
            Choose another topic
          </button>
          {topic && (
            <button
              type="button"
              onClick={() => startQuiz(topic)}
              className="flex items-center gap-1.5 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-medium text-white hover:bg-indigo-700"
            >
              <RotateCcw className="h-4 w-4" />
              New quiz
            </button>
          )}
        </div>
      </div>
    );
  }

  // stage === 'active'
  const q = questions[currentIndex];
  const progressPct = ((currentIndex + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b border-slate-100 bg-white/85 px-5 py-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-xl items-center gap-3">
          <button
            type="button"
            onClick={resetToPicker}
            aria-label="Exit quiz"
            className="flex h-9 w-9 items-center justify-center rounded-full text-slate-500 hover:bg-slate-100"
          >
            <ArrowLeft className="h-4.5 w-4.5" />
          </button>
          <div className="flex-1">
            <div className="mb-1 flex items-center justify-between text-xs font-medium text-slate-500">
              <span>Question {currentIndex + 1} of {questions.length}</span>
              <span className="text-indigo-600">{Math.round(progressPct)}%</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
              <div
                className="h-full rounded-full bg-gradient-to-r from-teal-500 to-indigo-500 transition-all duration-300"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-xl px-5 py-8">
        <div className="card-surface p-6">
          <span className="text-xs font-semibold uppercase tracking-wide text-indigo-500">
            {topic?.title}
          </span>
          <h2 className="mt-2 text-lg font-bold leading-snug text-slate-900">{q.question}</h2>
        </div>

        <div className="mt-6 grid gap-3">
          {q.options.map((option, idx) => {
            const isCorrect = idx === q.correctIndex;
            const isSelected = idx === selected;
            const revealed = selected !== null;

            let stateClasses = 'border-slate-200 bg-white hover:border-indigo-300';
            if (revealed && isCorrect) {
              stateClasses = 'border-teal-400 bg-teal-50';
            } else if (revealed && isSelected && !isCorrect) {
              stateClasses = 'border-red-300 bg-red-50';
            }

            return (
              <button
                key={idx}
                type="button"
                onClick={() => selectOption(idx)}
                disabled={revealed}
                className={`flex items-center justify-between gap-3 rounded-2xl border-2 px-4 py-3.5 text-left text-sm font-medium text-slate-800 transition-colors ${stateClasses} ${
                  revealed ? 'cursor-default' : 'active:scale-[0.99]'
                }`}
              >
                <span>{option}</span>
                {revealed && isCorrect && <CheckCircle2 className="h-5 w-5 shrink-0 text-teal-600" />}
                {revealed && isSelected && !isCorrect && (
                  <XCircle className="h-5 w-5 shrink-0 text-red-500" />
                )}
              </button>
            );
          })}
        </div>

        {selected !== null && (
          <div className="mt-5 rounded-2xl bg-indigo-50 px-4 py-3.5 text-sm leading-relaxed text-indigo-800">
            {q.explanation}
          </div>
        )}
      </main>

      {selected !== null && (
        <div className="sticky bottom-0 border-t border-slate-100 bg-white/90 px-5 py-4 backdrop-blur-md">
          <div className="mx-auto max-w-xl">
            <button
              type="button"
              onClick={nextQuestion}
              className="w-full rounded-full bg-indigo-600 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-indigo-700 active:scale-[0.99]"
            >
              {currentIndex + 1 < questions.length ? 'Next question' : 'See results'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
