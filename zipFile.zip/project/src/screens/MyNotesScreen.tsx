import { useEffect, useRef, useState } from 'react';
import {
  NotebookPen,
  PenLine,
  Plus,
  Trash2,
  Save,
  Image as ImageIcon,
  Loader2,
} from 'lucide-react';
import { ScreenHeader } from '@/components/ScreenHeader';
import { DrawingCanvas, type DrawingCanvasHandle } from '@/components/DrawingCanvas';
import { useAuth } from '@/context/AuthContext';
import {
  addNote,
  deleteNote,
  subscribeNotes,
  saveSketch,
  deleteSketch,
  subscribeSketches,
  type SavedSketch,
} from '@/utils/notesApi';
import type { UserNote } from '@/types';

type Tab = 'notes' | 'canvas';

export function MyNotesScreen() {
  const { user } = useAuth();
  const uid = user?.uid ?? '';

  const [tab, setTab] = useState<Tab>('notes');
  const [notes, setNotes] = useState<UserNote[]>([]);
  const [sketches, setSketches] = useState<SavedSketch[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!uid) return;
    setLoading(true);
    const unsubNotes = subscribeNotes(uid, (n) => setNotes(n));
    const unsubSketches = subscribeSketches(uid, (s) => {
      setSketches(s);
      setLoading(false);
    });
    return () => {
      unsubNotes();
      unsubSketches();
    };
  }, [uid]);

  return (
    <div className="min-h-screen">
      <ScreenHeader title="My Notes" subtitle="Text notes & freehand sketches" />
      <main className="mx-auto max-w-xl px-5 py-6">
        <div className="mb-5 flex rounded-2xl bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setTab('notes')}
            className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition-all ${
              tab === 'notes' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
            }`}
          >
            <NotebookPen className="h-4 w-4" />
            Text notes
          </button>
          <button
            type="button"
            onClick={() => setTab('canvas')}
            className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition-all ${
              tab === 'canvas' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
            }`}
          >
            <PenLine className="h-4 w-4" />
            Drawing canvas
          </button>
        </div>

        {tab === 'notes' ? (
          <TextNotesTab uid={uid} notes={notes} loading={loading} />
        ) : (
          <CanvasTab uid={uid} sketches={sketches} loading={loading} />
        )}
      </main>
    </div>
  );
}

function TextNotesTab({
  uid,
  notes,
  loading,
}: {
  uid: string;
  notes: UserNote[];
  loading: boolean;
}) {
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!uid) return;
    if (!title.trim() && !text.trim()) {
      setError('Add a title or some note text first.');
      return;
    }
    setError('');
    setSaving(true);
    try {
      await addNote(uid, title.trim() || 'Untitled note', text.trim());
      setTitle('');
      setText('');
    } catch (err) {
      setError('Could not save your note. Please try again.');
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(noteId: string) {
    try {
      await deleteNote(uid, noteId);
    } catch (err) {
      console.error('Failed to delete note:', err);
    }
  }

  if (loading) {
    return <LoadingState label="Loading your notes…" />;
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleAdd} className="card-surface space-y-3 p-5">
        <h2 className="text-base font-semibold text-slate-900">Add a new note</h2>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Note title"
          className="field-input"
        />
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Write your note…"
          rows={4}
          className="field-input resize-none"
        />
        {error && (
          <p role="alert" className="rounded-2xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700">
            {error}
          </p>
        )}
        <button type="submit" className="btn-primary" disabled={saving || !uid}>
          {saving ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Saving…
            </>
          ) : (
            <>
              <Plus className="mr-2 h-5 w-5" />
              Save note
            </>
          )}
        </button>
      </form>

      <div className="space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-400">
          Your saved notes ({notes.length})
        </h2>
        {notes.length === 0 ? (
          <EmptyState
            icon={<NotebookPen className="h-7 w-7" />}
            title="No notes yet"
            subtitle="Your saved text notes will appear here."
          />
        ) : (
          notes.map((note) => (
            <article key={note.id} className="card-surface p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <h3 className="font-semibold text-slate-900">{note.title}</h3>
                  {note.textContent && (
                    <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">
                      {note.textContent}
                    </p>
                  )}
                  <p className="mt-2 text-xs text-slate-400">
                    {new Date(note.updatedAt).toLocaleString()}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleDelete(note.id)}
                  aria-label={`Delete ${note.title}`}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-rose-50 hover:text-rose-600"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </article>
          ))
        )}
      </div>
    </div>
  );
}

function CanvasTab({
  uid,
  sketches,
  loading,
}: {
  uid: string;
  sketches: SavedSketch[];
  loading: boolean;
}) {
  const canvasRef = useRef<DrawingCanvasHandle | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [justSaved, setJustSaved] = useState(false);

  async function handleSave() {
    if (!uid) return;
    const dataUrl = canvasRef.current?.getDataUrl();
    if (!dataUrl) {
      setError('Draw something first, then save.');
      return;
    }
    setError('');
    setSaving(true);
    try {
      await saveSketch(uid, dataUrl);
      canvasRef.current?.clear();
      setJustSaved(true);
      setTimeout(() => setJustSaved(false), 1800);
    } catch (err) {
      setError('Could not save your drawing. Please try again.');
      console.error(err);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(sketchId: string) {
    try {
      await deleteSketch(uid, sketchId);
    } catch (err) {
      console.error('Failed to delete sketch:', err);
    }
  }

  if (loading) {
    return <LoadingState label="Loading your sketches…" />;
  }

  return (
    <div className="space-y-6">
      <div className="card-surface space-y-3 p-5">
        <div className="flex items-center gap-2">
          <PenLine className="h-5 w-5 text-teal-600" />
          <h2 className="text-base font-semibold text-slate-900">Freehand canvas</h2>
        </div>
        <p className="text-sm text-slate-500">
          Draw with your finger or mouse. Save to keep it in your account.
        </p>
        <DrawingCanvas ref={canvasRef} disabled={saving || !uid} />
        {error && (
          <p role="alert" className="rounded-2xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700">
            {error}
          </p>
        )}
        {justSaved && (
          <p className="rounded-2xl bg-teal-50 px-4 py-3 text-sm font-medium text-teal-700">
            Saved to your sketches.
          </p>
        )}
        <button type="button" onClick={handleSave} className="btn-primary" disabled={saving || !uid}>
          {saving ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Saving…
            </>
          ) : (
            <>
              <Save className="mr-2 h-5 w-5" />
              Save drawing
            </>
          )}
        </button>
      </div>

      <div className="space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-400">
          Your saved sketches ({sketches.length})
        </h2>
        {sketches.length === 0 ? (
          <EmptyState
            icon={<ImageIcon className="h-7 w-7" />}
            title="No sketches yet"
            subtitle="Your saved drawings will appear here."
          />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {sketches.map((sketch) => (
              <div key={sketch.id} className="card-surface overflow-hidden">
                <img
                  src={sketch.imageDataUrl}
                  alt="Saved sketch"
                  className="aspect-square w-full bg-white object-contain"
                />
                <div className="flex items-center justify-between gap-2 px-3 py-2">
                  <span className="truncate text-xs text-slate-400">
                    {new Date(sketch.updatedAt).toLocaleDateString()}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleDelete(sketch.id)}
                    aria-label="Delete sketch"
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-slate-400 transition-colors hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function LoadingState({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center py-16 text-slate-400">
      <Loader2 className="h-7 w-7 animate-spin" />
      <p className="mt-3 text-sm">{label}</p>
    </div>
  );
}

function EmptyState({
  icon,
  title,
  subtitle,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="card-surface flex flex-col items-center p-8 text-center">
      <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
        {icon}
      </span>
      <h3 className="font-semibold text-slate-900">{title}</h3>
      <p className="mt-1 max-w-xs text-sm text-slate-500">{subtitle}</p>
    </div>
  );
}
