import { useState } from 'react';
import { ArrowLeft, ChevronRight, GraduationCap, BookOpen, Image as ImageIcon } from 'lucide-react';
import { ScreenHeader } from '@/components/ScreenHeader';
import { A2_TOPICS } from '@/data/a2Topics';
import type { Topic, Subtopic } from '@/types';

export function A2TopicsScreen() {
  const [activeTopic, setActiveTopic] = useState<Topic | null>(null);

  if (activeTopic) {
    return <TopicDetail topic={activeTopic} onBack={() => setActiveTopic(null)} />;
  }

  return (
    <div className="min-h-screen">
      <ScreenHeader title="A2 Chem Notes" subtitle="Pick a topic to begin" />
      <main className="mx-auto max-w-xl px-5 py-8">
        <div className="grid gap-4">
          {A2_TOPICS.map((topic) => (
            <button
              key={topic.id}
              type="button"
              onClick={() => setActiveTopic(topic)}
              className="card-surface group flex items-center gap-4 p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:shadow-cardHover focus:outline-none focus:ring-4 focus:ring-indigo-300/30 active:scale-[0.99]"
            >
              <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-sm transition-transform group-hover:scale-105">
                <GraduationCap className="h-7 w-7" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="text-base font-semibold text-slate-900">{topic.title}</span>
                <span className="mt-0.5 block text-sm text-slate-500">
                  {topic.subtopics.length} subtopics
                </span>
              </span>
              <ChevronRight className="h-5 w-5 shrink-0 text-slate-400 transition-transform group-hover:translate-x-0.5" />
            </button>
          ))}
        </div>
      </main>
    </div>
  );
}

function TopicDetail({ topic, onBack }: { topic: Topic; onBack: () => void }) {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b border-slate-100 bg-white/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-xl items-center gap-3 px-5 py-4">
          <button
            type="button"
            onClick={onBack}
            aria-label="Back to topics"
            className="flex h-10 w-10 items-center justify-center rounded-full text-slate-600 transition-colors hover:bg-slate-100 active:scale-95"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-lg font-semibold text-slate-900">{topic.title}</h1>
            <p className="truncate text-sm text-slate-500">{topic.subtopics.length} subtopics</p>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-xl px-5 py-8">
        <div className="mb-6 flex items-center gap-2 rounded-2xl bg-indigo-50 px-4 py-3 text-sm text-indigo-700">
          <BookOpen className="h-4 w-4 shrink-0" />
          <span>Read through each subtopic — key definitions are highlighted below the body text.</span>
        </div>

        <div className="space-y-6">
          {topic.subtopics.map((sub, idx) => (
            <SubtopicCard key={sub.id} subtopic={sub} index={idx} />
          ))}
        </div>
      </main>
    </div>
  );
}

function SubtopicCard({ subtopic, index }: { subtopic: Subtopic; index: number }) {
  return (
    <section className="card-surface p-5">
      <div className="mb-3 flex items-center gap-3">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-indigo-100 text-sm font-bold text-indigo-700">
          {index + 1}
        </span>
        <h2 className="text-lg font-bold text-slate-900">{subtopic.title}</h2>
      </div>

      <p className="text-[15px] leading-relaxed text-slate-700">{subtopic.bodyText}</p>

      {subtopic.diagramImageUrls.length > 0 && (
        <div className="mt-4 grid gap-3">
          {subtopic.diagramImageUrls.map((url, i) => (
            <figure
              key={i}
              className="overflow-hidden rounded-2xl border border-slate-200 bg-slate-50"
            >
              <img
                src={url}
                alt={`${subtopic.title} diagram ${i + 1}`}
                className="h-auto w-full object-contain"
                loading="lazy"
              />
            </figure>
          ))}
        </div>
      )}

      {subtopic.keyDefinitions.length > 0 && (
        <div className="mt-4 rounded-2xl border border-teal-100 bg-teal-50/60 p-4">
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-teal-700">
            Key definitions
          </h3>
          <ul className="space-y-2">
            {subtopic.keyDefinitions.map((def, i) => (
              <li key={i} className="flex gap-2 text-sm leading-relaxed text-slate-700">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-teal-500" />
                <span>{def}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {subtopic.diagramImageUrls.length === 0 && (
        <div className="mt-4 flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-400">
          <ImageIcon className="h-3.5 w-3.5 shrink-0" />
          <span>Diagrams for this subtopic will be added shortly.</span>
        </div>
      )}
    </section>
  );
}
