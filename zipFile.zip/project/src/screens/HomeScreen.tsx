import { BookOpen, GraduationCap, BrainCircuit, NotebookPen, LogOut, Sparkles } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useNavigation, type ScreenName } from '@/context/NavigationContext';
import { useState } from 'react';

interface DashboardCard {
  key: string;
  title: string;
  description: string;
  icon: typeof BookOpen;
  target: ScreenName;
  badge?: string;
  gradient: string;
}

const CARDS: DashboardCard[] = [
  {
    key: 'as',
    title: 'AS Chem Notes',
    description: 'First-year theory & key concepts',
    icon: BookOpen,
    target: 'as-notes',
    badge: 'Coming Soon',
    gradient: 'from-teal-500 to-teal-600',
  },
  {
    key: 'a2',
    title: 'A2 Chem Notes',
    description: 'Second-year topics & subtopics',
    icon: GraduationCap,
    target: 'a2-topics',
    gradient: 'from-indigo-500 to-indigo-600',
  },
  {
    key: 'quiz',
    title: 'Custom AI Quiz',
    description: 'Test yourself on any topic',
    icon: BrainCircuit,
    target: 'quiz-picker',
    gradient: 'from-teal-500 to-indigo-500',
  },
  {
    key: 'notes',
    title: 'My Notes',
    description: 'Text notes & freehand sketches',
    icon: NotebookPen,
    target: 'my-notes',
    gradient: 'from-indigo-500 to-teal-500',
  },
];

export function HomeScreen() {
  const { user, logOut } = useAuth();
  const { navigate } = useNavigation();
  const [showComingSoon, setShowComingSoon] = useState(false);

  const greetingName = user?.displayName || user?.email?.split('@')[0] || 'there';

  async function handleCard(card: DashboardCard) {
    if (card.badge === 'Coming Soon') {
      setShowComingSoon(true);
      return;
    }
    navigate(card.target);
  }

  return (
    <div className="min-h-screen">
      <header className="px-5 pb-2 pt-10">
        <div className="mx-auto flex max-w-xl items-center justify-between">
          <div className="flex items-center gap-2 text-slate-900">
            <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-indigo-500 text-white">
              <Sparkles className="h-5 w-5" />
            </span>
            <span className="text-lg font-bold">ChemMate</span>
          </div>
          <button
            type="button"
            onClick={logOut}
            className="flex items-center gap-1.5 rounded-full px-3 py-2 text-sm font-medium text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700"
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-xl px-5 pb-12 pt-6">
        <div className="mb-6">
          <p className="text-sm font-medium text-teal-600">Welcome back</p>
          <h1 className="mt-0.5 text-2xl font-bold tracking-tight text-slate-900">
            Hi, {greetingName}
          </h1>
          <p className="mt-1 text-sm text-slate-500">What would you like to study today?</p>
        </div>

        <div className="grid gap-4">
          {CARDS.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.key}
                type="button"
                onClick={() => handleCard(card)}
                className="card-surface group flex items-center gap-4 p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:shadow-cardHover focus:outline-none focus:ring-4 focus:ring-teal-300/30 active:scale-[0.99]"
              >
                <span
                  className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${card.gradient} text-white shadow-sm transition-transform group-hover:scale-105`}
                >
                  <Icon className="h-7 w-7" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className="text-base font-semibold text-slate-900">{card.title}</span>
                    {card.badge && (
                      <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-amber-700">
                        {card.badge}
                      </span>
                    )}
                  </span>
                  <span className="mt-0.5 block text-sm text-slate-500">{card.description}</span>
                </span>
              </button>
            );
          })}
        </div>
      </main>

      {showComingSoon && <ComingSoonDialog onClose={() => setShowComingSoon(false)} />}
    </div>
  );
}

function ComingSoonDialog({ onClose }: { onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 px-5 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="card-surface w-full max-w-sm p-6 text-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-amber-100 text-amber-600">
          <Sparkles className="h-8 w-8" />
        </div>
        <h2 className="text-lg font-bold text-slate-900">Launching soon!</h2>
        <p className="mt-2 text-sm text-slate-500">
          This section is launching soon! We&apos;re still brewing up the AS Chemistry notes for
          you. Check back shortly.
        </p>
        <button type="button" onClick={onClose} className="btn-primary mt-5">
          Got it
        </button>
      </div>
    </div>
  );
}
