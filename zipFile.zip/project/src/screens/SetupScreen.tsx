import { FlaskConical, KeyRound, ExternalLink } from 'lucide-react';
import { missingFirebaseKeys } from '@/firebase';

export function SetupScreen() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-5 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-teal-500 to-indigo-500 text-white shadow-cardHover">
            <FlaskConical className="h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">ChemMate</h1>
          <p className="mt-1 text-sm text-slate-500">Almost ready — one setup step to go.</p>
        </div>

        <div className="card-surface p-6">
          <div className="mb-4 flex items-center gap-2 text-slate-900">
            <KeyRound className="h-5 w-5 text-teal-600" />
            <h2 className="text-base font-semibold">Add your Firebase keys</h2>
          </div>

          <p className="text-sm leading-relaxed text-slate-600">
            ChemMate uses Firebase for login and saving your notes. Before it can
            run, you need to paste your Firebase project&apos;s config into a
            file called <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs font-mono">.env</code> in
            the project root.
          </p>

          {missingFirebaseKeys.length > 0 && (
            <div className="mt-4 rounded-2xl bg-amber-50 px-4 py-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-amber-700">
                Still missing
              </p>
              <ul className="mt-2 space-y-1">
                {missingFirebaseKeys.map((k) => (
                  <li key={k} className="font-mono text-sm text-amber-800">
                    VITE_FIREBASE_{k.toUpperCase().replace(/_/g, '_')}=
                  </li>
                ))}
              </ul>
            </div>
          )}

          <ol className="mt-5 space-y-3 text-sm text-slate-600">
            <li className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-teal-100 text-xs font-bold text-teal-700">
                1
              </span>
              <span>
                Go to the{' '}
                <a
                  href="https://console.firebase.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-0.5 font-semibold text-teal-600 hover:underline"
                >
                  Firebase console
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>{' '}
                and create or open a project.
              </span>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-teal-100 text-xs font-bold text-teal-700">
                2
              </span>
              <span>
                In <strong>Project settings → Your apps</strong>, add a Web app and
                copy the config values.
              </span>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-teal-100 text-xs font-bold text-teal-700">
                3
              </span>
              <span>
                Enable <strong>Authentication → Email/Password</strong> and create
                a <strong>Firestore Database</strong>.
              </span>
            </li>
            <li className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-teal-100 text-xs font-bold text-teal-700">
                4
              </span>
              <span>
                Paste the six <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs font-mono">VITE_FIREBASE_*</code> values
                into <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs font-mono">.env</code>{' '}
                (see <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs font-mono">.env.example</code>), then share them here.
              </span>
            </li>
          </ol>

          <div className="mt-5 rounded-2xl bg-slate-50 px-4 py-3 text-xs text-slate-500">
            The full step-by-step guide and the security rules to paste into
            Firestore are in the project&apos;s <strong>README.md</strong>.
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-slate-400">
          Once the keys are in, this screen disappears and login opens automatically.
        </p>
      </div>
    </div>
  );
}
